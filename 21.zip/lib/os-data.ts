import type { LucideIcon } from "lucide-react"
import {
  Armchair,
  Trash2,
  Sprout,
  Lamp,
  Droplets,
  Droplet,
  Zap,
  TreeDeciduous,
  Building2,
  Recycle,
  ShieldCheck,
  TriangleAlert,
  Plus,
  Wrench,
  Vote,
  Baby,
  Trees,
} from "lucide-react"

export type Task = {
  id: number
  title: string
  icon: LucideIcon
  xp: number
  karma: number
  distance: string
  category: "available" | "mine"
}

export const TASKS: Task[] = [
  { id: 1, title: "Починить скамейку", icon: Armchair, xp: 50, karma: 18, distance: "120 м", category: "available" },
  {
    id: 2,
    title: "Установить контейнер для раздельного сбора",
    icon: Trash2,
    xp: 80,
    karma: 25,
    distance: "340 м",
    category: "available",
  },
  { id: 3, title: "Озеленить двор", icon: Sprout, xp: 60, karma: 20, distance: "210 м", category: "mine" },
  { id: 4, title: "Проверить освещение", icon: Lamp, xp: 40, karma: 12, distance: "150 м", category: "available" },
  { id: 5, title: "Устранить утечку воды", icon: Droplets, xp: 70, karma: 22, distance: "300 м", category: "mine" },
]

export type EncCategory = {
  title: string
  count: number
  icon: LucideIcon
  group: "home" | "eco" | "law"
}

export const ENCYCLOPEDIA: EncCategory[] = [
  { title: "Водоснабжение", count: 24, icon: Droplet, group: "home" },
  { title: "Энергосбережение", count: 18, icon: Zap, group: "eco" },
  { title: "Озеленение", count: 31, icon: TreeDeciduous, group: "eco" },
  { title: "Управление МКД", count: 27, icon: Building2, group: "law" },
  { title: "Раздельный сбор", count: 22, icon: Recycle, group: "eco" },
  { title: "Безопасность", count: 15, icon: ShieldCheck, group: "law" },
]

export type ForumPost = {
  id: number
  author: string
  time: string
  title: string
  comments: number
  likes: number
}

export const FORUM: ForumPost[] = [
  { id: 1, author: "сосед_87", time: "2 мин назад", title: "Шумные соседи по ночам", comments: 12, likes: 24 },
  {
    id: 2,
    author: "цветочный_активист",
    time: "15 мин назад",
    title: "Предложение: сделать площадку для выгула собак",
    comments: 8,
    likes: 37,
  },
  {
    id: 3,
    author: "юрист_онлайн",
    time: "1 час назад",
    title: "Как оспорить незаконную перепланировку?",
    comments: 5,
    likes: 19,
  },
]

export type FundProject = {
  id: number
  title: string
  icon: LucideIcon
  raised: number
  goal: number
  daysLeft: number
  status: "active" | "success"
}

export const FUND: FundProject[] = [
  {
    id: 1,
    title: "Детская площадка во дворе",
    icon: Baby,
    raised: 750000,
    goal: 1200000,
    daysLeft: 12,
    status: "active",
  },
  {
    id: 2,
    title: "Озеленение аллеи у дома",
    icon: Trees,
    raised: 310000,
    goal: 500000,
    daysLeft: 8,
    status: "active",
  },
  { id: 3, title: "Новые лавки и урны", icon: Armchair, raised: 125000, goal: 250000, daysLeft: 5, status: "active" },
]

export type BudgetItem = { label: string; pct: number; amount: number }

export const BUDGET_TOTAL = 2500000
export const BUDGET: BudgetItem[] = [
  { label: "Благоустройство", pct: 40, amount: 1000000 },
  { label: "Инфраструктура", pct: 25, amount: 625000 },
  { label: "Безопасность", pct: 15, amount: 375000 },
  { label: "Экология", pct: 10, amount: 250000 },
  { label: "Образование", pct: 10, amount: 250000 },
]

export type MapPoint = {
  id: number
  x: number
  y: number
  type: "problem" | "task" | "project" | "vote"
  label: string
}

export const MAP_POINTS: MapPoint[] = [
  { id: 1, x: 30, y: 22, type: "project", label: "Детская площадка" },
  { id: 2, x: 20, y: 45, type: "problem", label: "Яма на дороге" },
  { id: 3, x: 58, y: 34, type: "task", label: "Починить скамейку" },
  { id: 4, x: 50, y: 58, type: "project", label: "Озеленение аллеи" },
  { id: 5, x: 40, y: 75, type: "vote", label: "Голосование по парковке" },
]

export const MAP_TYPES: { key: MapPoint["type"]; label: string; icon: LucideIcon }[] = [
  { key: "problem", label: "Проблемы", icon: TriangleAlert },
  { key: "task", label: "Задачи", icon: Wrench },
  { key: "project", label: "Проекты", icon: Plus },
  { key: "vote", label: "Голосования", icon: Vote },
]

export const AI_SUGGESTIONS = [
  "Как решить проблему с водой?",
  "Как создать задачу?",
  "Как провести голосование?",
  "Как сделать двор лучше?",
]

export function formatMoney(n: number) {
  return n.toLocaleString("ru-RU")
}
