"use client"

import type { LucideIcon } from "lucide-react"
import { Signal, Wifi, BatteryMedium } from "lucide-react"
import { cn } from "@/lib/utils"

export function StatusBar() {
  return (
    <div className="flex items-center justify-between px-4 py-2 text-xs font-mono">
      <span className="font-bold tabular-nums">21:21</span>
      <div className="flex items-center gap-1.5">
        <Signal className="h-3.5 w-3.5" strokeWidth={2.5} />
        <Wifi className="h-3.5 w-3.5" strokeWidth={2.5} />
        <BatteryMedium className="h-4 w-4" strokeWidth={2.5} />
      </div>
    </div>
  )
}

export function ScreenHeader({
  title,
  left,
  right,
}: {
  title: string
  left?: React.ReactNode
  right?: React.ReactNode
}) {
  return (
    <div className="flex items-center justify-between border-b-2 border-border px-4 py-3">
      <div className="flex h-8 w-8 items-center justify-center">{left}</div>
      <h1 className="font-display text-lg font-bold uppercase tracking-wide">{title}</h1>
      <div className="flex h-8 w-8 items-center justify-center">{right}</div>
    </div>
  )
}

export function PixelIcon({
  icon: Icon,
  size = "md",
  filled = false,
  className,
}: {
  icon: LucideIcon
  size?: "sm" | "md" | "lg"
  filled?: boolean
  className?: string
}) {
  const box = size === "sm" ? "h-9 w-9" : size === "lg" ? "h-14 w-14" : "h-11 w-11"
  const ic = size === "sm" ? "h-4 w-4" : size === "lg" ? "h-7 w-7" : "h-5 w-5"
  return (
    <div
      className={cn(
        "flex shrink-0 items-center justify-center border-2 border-border",
        filled ? "bg-foreground text-background" : "bg-card text-foreground",
        box,
        className,
      )}
    >
      <Icon className={ic} strokeWidth={2.25} />
    </div>
  )
}

export function TabBar<T extends string>({
  tabs,
  active,
  onChange,
}: {
  tabs: { key: T; label: string }[]
  active: T
  onChange: (k: T) => void
}) {
  return (
    <div className="flex items-stretch gap-0 overflow-x-auto border-2 border-border scrollbar-none">
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => onChange(t.key)}
          className={cn(
            "flex-1 whitespace-nowrap px-3 py-2 text-[11px] font-bold uppercase tracking-wide transition-colors",
            active === t.key ? "bg-foreground text-background" : "bg-card text-muted-foreground hover:text-foreground",
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  )
}

export function ProgressBar({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn("h-3 w-full border-2 border-border bg-card", className)}>
      <div className="h-full dither" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  )
}

export function PixelButton({
  children,
  onClick,
  variant = "solid",
  className,
  type = "button",
}: {
  children: React.ReactNode
  onClick?: () => void
  variant?: "solid" | "outline"
  className?: string
  type?: "button" | "submit"
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className={cn(
        "flex w-full items-center justify-center gap-2 border-2 border-border px-4 py-3 text-sm font-bold uppercase tracking-wide pixel-shadow-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none",
        variant === "solid" ? "bg-foreground text-background" : "bg-card text-foreground",
        className,
      )}
    >
      {children}
    </button>
  )
}

export function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cn("border-2 border-border bg-card", className)}>{children}</div>
}
