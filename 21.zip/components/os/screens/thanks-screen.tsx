"use client"

import Image from "next/image"
import { Download } from "lucide-react"
import { ScreenHeader, PixelButton } from "@/components/os/primitives"

export function ThanksScreen({ onDone }: { onDone: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title="Спасибо!" />

      <div className="flex flex-1 flex-col items-center justify-center gap-6 px-6 py-6">
        <div className="flex items-center gap-4">
          <Image
            src="/pixel/character.png"
            alt="Пиксельный житель района держит табличку"
            width={140}
            height={140}
            className="pixelated h-32 w-32 object-contain"
          />
          <QrCode />
        </div>

        <p className="max-w-[16rem] text-center font-display text-lg font-bold uppercase leading-tight text-balance">
          Скачай стикер и делись приложением с соседями!
        </p>
      </div>

      <div className="space-y-3 border-t-2 border-border p-4">
        <PixelButton>
          <Download className="h-4 w-4" strokeWidth={2.75} /> Скачать стикер
        </PixelButton>
        <PixelButton variant="outline" onClick={onDone}>
          Готово
        </PixelButton>
      </div>
    </div>
  )
}

/* Deterministic pixel "QR" made of border blocks */
function QrCode() {
  const size = 11
  const cells: boolean[] = []
  for (let i = 0; i < size * size; i++) {
    const r = Math.floor(i / size)
    const c = i % size
    const finder =
      (r < 3 && c < 3) || (r < 3 && c > size - 4) || (r > size - 4 && c < 3)
    cells.push(finder || (i * 73 + r * 13 + c * 7) % 5 < 2)
  }
  return (
    <div
      className="grid border-2 border-border bg-card p-1"
      style={{ gridTemplateColumns: `repeat(${size}, 1fr)`, width: 128, height: 128 }}
      role="img"
      aria-label="QR-код для скачивания стикера"
    >
      {cells.map((on, i) => (
        <div key={i} className={on ? "bg-foreground" : "bg-card"} />
      ))}
    </div>
  )
}
