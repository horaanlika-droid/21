"use client"

import { useState } from "react"
import { ChevronLeft, SlidersHorizontal, MapPin, Check, Plus } from "lucide-react"
import { ScreenHeader, TabBar, PixelIcon } from "@/components/os/primitives"
import { TASKS, type Task } from "@/lib/os-data"
import { cn } from "@/lib/utils"

type Filter = "all" | "available" | "mine" | "done"

const TABS: { key: Filter; label: string }[] = [
  { key: "all", label: "Все" },
  { key: "available", label: "Доступные" },
  { key: "mine", label: "Мои" },
  { key: "done", label: "Выполнены" },
]

export function TasksScreen({
  done,
  onComplete,
  onBack,
}: {
  done: Set<number>
  onComplete: (t: Task) => void
  onBack: () => void
}) {
  const [filter, setFilter] = useState<Filter>("all")

  const visible = TASKS.filter((t) => {
    if (filter === "done") return done.has(t.id)
    if (filter === "all") return true
    if (filter === "available") return t.category === "available" && !done.has(t.id)
    if (filter === "mine") return t.category === "mine"
    return true
  })

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader
        title="Активные задачи"
        left={
          <button aria-label="Назад" onClick={onBack} className="flex h-8 w-8 items-center justify-center">
            <ChevronLeft className="h-6 w-6" strokeWidth={2.5} />
          </button>
        }
        right={
          <button aria-label="Фильтр" className="flex h-8 w-8 items-center justify-center">
            <SlidersHorizontal className="h-5 w-5" strokeWidth={2.25} />
          </button>
        }
      />

      <div className="px-4 py-3">
        <TabBar tabs={TABS} active={filter} onChange={setFilter} />
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-4 pb-6 scrollbar-none">
        {visible.length === 0 && (
          <p className="py-10 text-center text-sm uppercase tracking-wide text-muted-foreground">Пока пусто</p>
        )}
        {visible.map((t) => {
          const isDone = done.has(t.id)
          return (
            <div key={t.id} className="flex items-center gap-3 border-2 border-border bg-card p-3 pixel-shadow-sm">
              <PixelIcon icon={t.icon} filled={isDone} />
              <div className="min-w-0 flex-1">
                <p className="font-display text-sm font-bold uppercase leading-tight">{t.title}</p>
                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                  <span>+{t.xp} XP</span>
                  <span>+{t.karma} КАРМЫ</span>
                  <span className="flex items-center gap-0.5">
                    <MapPin className="h-3 w-3" strokeWidth={2.5} /> {t.distance}
                  </span>
                </div>
              </div>
              <button
                aria-label={isDone ? "Выполнено" : "Взять задачу"}
                disabled={isDone}
                onClick={() => onComplete(t)}
                className={cn(
                  "flex h-10 w-10 shrink-0 items-center justify-center border-2 border-border transition-all",
                  isDone
                    ? "bg-foreground text-background"
                    : "bg-card text-foreground active:translate-x-[2px] active:translate-y-[2px]",
                )}
              >
                {isDone ? <Check className="h-5 w-5" strokeWidth={3} /> : <Plus className="h-5 w-5" strokeWidth={3} />}
              </button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
