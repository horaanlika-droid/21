"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import { X, SendHorizontal } from "lucide-react"
import { AI_SUGGESTIONS } from "@/lib/os-data"
import { cn } from "@/lib/utils"

type Msg = { role: "ai" | "user"; text: string }

const CANNED: Record<string, string> = {
  default: "Расскажите подробнее — я подскажу шаги и оформлю задачу для района.",
}

export function AiAssistant({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [messages, setMessages] = useState<Msg[]>([{ role: "ai", text: "Чем могу помочь?" }])
  const [input, setInput] = useState("")
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, open])

  if (!open) return null

  function send(text: string) {
    const t = text.trim()
    if (!t) return
    setMessages((m) => [...m, { role: "user", text: t }])
    setInput("")
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        { role: "ai", text: `«${t}» — ${CANNED.default}` },
      ])
    }, 450)
  }

  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-background">
      <div className="flex items-center justify-between border-b-2 border-border px-4 py-3">
        <span className="w-8" />
        <h1 className="font-display text-lg font-bold uppercase tracking-wide">AI-Ассистент</h1>
        <button aria-label="Закрыть" onClick={onClose} className="flex h-8 w-8 items-center justify-center">
          <X className="h-6 w-6" strokeWidth={2.5} />
        </button>
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4 scrollbar-none">
        <div className="flex items-start gap-3">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center border-2 border-border bg-card">
            <Image
              src="/pixel/robot.png"
              alt="Пиксельный робот-ассистент"
              width={56}
              height={56}
              className="pixelated h-12 w-12 object-contain"
            />
          </div>
          <Bubble role="ai">{messages[0].text}</Bubble>
        </div>

        {messages.slice(1).map((m, i) => (
          <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start pl-[68px]")}>
            <Bubble role={m.role}>{m.text}</Bubble>
          </div>
        ))}

        {messages.length === 1 && (
          <div className="space-y-2 pt-1">
            {AI_SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="flex w-full items-center border-2 border-border bg-card px-3 py-3 text-left text-xs font-bold uppercase tracking-wide pixel-shadow-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
              >
                {s}
              </button>
            ))}
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault()
          send(input)
        }}
        className="flex items-center gap-2 border-t-2 border-border p-3"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Напишите сообщение..."
          className="min-w-0 flex-1 border-2 border-border bg-card px-3 py-3 text-sm uppercase tracking-wide placeholder:text-muted-foreground focus:outline-none focus:ring-0"
        />
        <button
          type="submit"
          aria-label="Отправить"
          className="flex h-11 w-11 shrink-0 items-center justify-center border-2 border-border bg-foreground text-background"
        >
          <SendHorizontal className="h-5 w-5" strokeWidth={2.5} />
        </button>
      </form>
    </div>
  )
}

function Bubble({ role, children }: { role: "ai" | "user"; children: React.ReactNode }) {
  return (
    <div
      className={cn(
        "max-w-[80%] border-2 border-border px-3 py-2 text-sm leading-snug",
        role === "user" ? "bg-foreground text-background" : "bg-card text-foreground",
      )}
    >
      {children}
    </div>
  )
}
