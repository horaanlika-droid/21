"use client"

import Image from "next/image"
import { Heart, Plus, Bell, ChevronRight, Sparkles, Coins, HandCoins, Bot } from "lucide-react"
import { Card, PixelButton, ProgressBar } from "@/components/os/primitives"
import { formatMoney } from "@/lib/os-data"
import type { View } from "@/app/page"

export function HomeScreen({
  karma,
  xp,
  level,
  levelCurrent,
  levelNeed,
  activeCount,
  onNavigate,
  onOpenAi,
}: {
  karma: number
  xp: number
  level: number
  levelCurrent: number
  levelNeed: number
  activeCount: number
  onNavigate: (v: View) => void
  onOpenAi: () => void
}) {
  return (
    <div className="flex flex-col gap-4 px-4 pb-6 pt-2">
      {/* Masthead */}
      <div className="flex items-end justify-between">
        <div>
          <div className="font-display text-6xl font-bold leading-none">21</div>
          <div className="mt-1 text-[11px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
            Городская ОС
          </div>
        </div>
        <button
          aria-label="Уведомления"
          className="flex h-10 w-10 items-center justify-center border-2 border-border bg-card pixel-shadow-sm"
        >
          <Bell className="h-5 w-5" strokeWidth={2.25} />
        </button>
      </div>

      {/* Stats card */}
      <Card className="p-4 pixel-shadow">
        <div className="flex items-stretch gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
              <Heart className="h-3.5 w-3.5" fill="currentColor" /> Карма
            </div>
            <div className="font-display text-3xl font-bold tabular-nums">{formatMoney(karma)}</div>
          </div>
          <div className="w-px bg-border" />
          <div className="flex-1">
            <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5" /> XP
            </div>
            <div className="font-display text-3xl font-bold tabular-nums">{formatMoney(xp)}</div>
          </div>
          <button
            aria-label="Добавить"
            onClick={() => onNavigate("tasks")}
            className="flex h-10 w-10 items-center justify-center self-center border-2 border-border bg-foreground text-background"
          >
            <Plus className="h-5 w-5" strokeWidth={3} />
          </button>
        </div>

        <div className="mt-4 flex items-center justify-between text-[11px] font-bold uppercase tracking-wide">
          <span>Уровень {level}</span>
          <span className="tabular-nums text-muted-foreground">
            {formatMoney(levelCurrent)} / {formatMoney(levelNeed)} XP
          </span>
        </div>
        <ProgressBar className="mt-1.5" value={(levelCurrent / levelNeed) * 100} />
      </Card>

      {/* Neighborhood illustration + speech bubble */}
      <Card className="relative overflow-hidden">
        <div className="absolute left-3 top-3 z-10 max-w-[62%] border-2 border-border bg-card px-3 py-2">
          <div className="font-display text-sm font-bold uppercase leading-tight">Район Цветочный</div>
          <div className="mt-0.5 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
            Живём лучше каждый день
          </div>
        </div>
        <Image
          src="/pixel/neighborhood.png"
          alt="Пиксельная иллюстрация района: жилые дома, деревья и житель на переднем плане"
          width={480}
          height={360}
          className="pixelated h-48 w-full object-cover"
          priority
        />
      </Card>

      {/* Active tasks CTA */}
      <PixelButton onClick={() => onNavigate("tasks")}>
        <span className="flex-1 text-left">Активные задачи</span>
        <span className="flex h-6 w-6 items-center justify-center border border-background/60 tabular-nums">
          {activeCount}
        </span>
        <ChevronRight className="h-4 w-4" strokeWidth={3} />
      </PixelButton>

      {/* Quick tiles */}
      <div className="grid grid-cols-2 gap-3">
        <QuickTile icon={HandCoins} label="Краудфандинг" onClick={() => onNavigate("crowdfunding")} />
        <QuickTile icon={Coins} label="Бюджет района" onClick={() => onNavigate("budget")} />
        <QuickTile icon={Bot} label="AI-ассистент" onClick={onOpenAi} />
        <QuickTile icon={Sparkles} label="Поделиться" onClick={() => onNavigate("thanks")} />
      </div>
    </div>
  )
}

function QuickTile({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Coins
  label: string
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 border-2 border-border bg-card px-3 py-3 text-left pixel-shadow-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
    >
      <Icon className="h-5 w-5 shrink-0" strokeWidth={2.25} />
      <span className="text-[11px] font-bold uppercase leading-tight tracking-wide">{label}</span>
    </button>
  )
}
