"use client"

import { useState } from "react"
import { SquarePen, MessageSquare, Heart } from "lucide-react"
import { ScreenHeader, TabBar } from "@/components/os/primitives"
import { FORUM } from "@/lib/os-data"

type Tab = "latest" | "hot" | "mine"

const TABS: { key: Tab; label: string }[] = [
  { key: "latest", label: "Последние" },
  { key: "hot", label: "Обсуждаемые" },
  { key: "mine", label: "Мои" },
]

export function ForumScreen() {
  const [tab, setTab] = useState<Tab>("latest")
  const [liked, setLiked] = useState<Set<number>>(new Set())

  const posts =
    tab === "hot" ? [...FORUM].sort((a, b) => b.comments + b.likes - (a.comments + a.likes)) : FORUM

  function toggleLike(id: number) {
    setLiked((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader
        title="Форум"
        right={
          <button aria-label="Создать пост" className="flex h-8 w-8 items-center justify-center">
            <SquarePen className="h-5 w-5" strokeWidth={2.25} />
          </button>
        }
      />

      <div className="px-4 py-3">
        <TabBar tabs={TABS} active={tab} onChange={setTab} />
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-4 pb-6 scrollbar-none">
        {tab === "mine" ? (
          <p className="py-10 text-center text-sm uppercase tracking-wide text-muted-foreground">
            У вас пока нет тем
          </p>
        ) : (
          posts.map((p) => {
            const isLiked = liked.has(p.id)
            return (
              <article key={p.id} className="border-2 border-border bg-card p-3 pixel-shadow-sm">
                <header className="flex items-center gap-2">
                  <div className="dither-soft flex h-9 w-9 items-center justify-center border-2 border-border bg-card">
                    <span className="font-display text-xs font-bold">{p.author.slice(0, 2).toUpperCase()}</span>
                  </div>
                  <div className="leading-tight">
                    <p className="text-xs font-bold uppercase">{p.author}</p>
                    <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{p.time}</p>
                  </div>
                </header>
                <h2 className="mt-2 font-display text-base font-bold uppercase leading-tight text-balance">
                  {p.title}
                </h2>
                <footer className="mt-2.5 flex items-center gap-4 text-[11px] font-bold uppercase text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MessageSquare className="h-3.5 w-3.5" strokeWidth={2.5} /> {p.comments}
                  </span>
                  <button onClick={() => toggleLike(p.id)} className="flex items-center gap-1 text-foreground">
                    <Heart className="h-3.5 w-3.5" strokeWidth={2.5} fill={isLiked ? "currentColor" : "none"} />
                    {p.likes + (isLiked ? 1 : 0)}
                  </button>
                </footer>
              </article>
            )
          })
        )}
      </div>
    </div>
  )
}
