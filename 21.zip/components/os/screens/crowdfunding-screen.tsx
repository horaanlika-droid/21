"use client"

import { useState } from "react"
import { ChevronLeft, SlidersHorizontal, Clock } from "lucide-react"
import { ScreenHeader, TabBar, PixelIcon, PixelButton, ProgressBar } from "@/components/os/primitives"
import { FUND, formatMoney } from "@/lib/os-data"

type Tab = "all" | "active" | "success" | "mine"

const TABS: { key: Tab; label: string }[] = [
  { key: "all", label: "Все" },
  { key: "active", label: "Сбор идёт" },
  { key: "success", label: "Успешные" },
  { key: "mine", label: "Мои" },
]

export function CrowdfundingScreen({ onBack }: { onBack: () => void }) {
  const [tab, setTab] = useState<Tab>("all")
  const visible = FUND.filter((p) => {
    if (tab === "all" || tab === "mine") return true
    return p.status === tab
  })

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader
        title="Краудфандинг"
        left={
          <button aria-label="Назад" onClick={onBack} className="flex h-8 w-8 items-center justify-center">
            <ChevronLeft className="h-6 w-6" strokeWidth={2.5} />
          </button>
        }
        right={
          <button aria-label="Фильтр" className="flex h-8 w-8 items-center justify-center">
            <SlidersHorizontal className="h-5 w-5" strokeWidth={2.25} />
          </button>
        }
      />

      <div className="px-4 py-3">
        <TabBar tabs={TABS} active={tab} onChange={setTab} />
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-4 pb-4 scrollbar-none">
        {visible.map((p) => {
          const pct = Math.round((p.raised / p.goal) * 100)
          return (
            <div key={p.id} className="border-2 border-border bg-card p-3 pixel-shadow-sm">
              <div className="flex items-start gap-3">
                <PixelIcon icon={p.icon} size="lg" />
                <div className="min-w-0 flex-1">
                  <p className="font-display text-sm font-bold uppercase leading-tight text-balance">{p.title}</p>
                  <p className="mt-1 text-[11px] font-bold uppercase tabular-nums text-muted-foreground">
                    {formatMoney(p.raised)} / {formatMoney(p.goal)} ₽
                  </p>
                </div>
                <span className="font-display text-lg font-bold tabular-nums">{pct}%</span>
              </div>
              <ProgressBar className="mt-3" value={pct} />
              <div className="mt-2 flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                <Clock className="h-3.5 w-3.5" strokeWidth={2.5} /> до конца: {p.daysLeft} дней
              </div>
            </div>
          )
        })}
      </div>

      <div className="border-t-2 border-border p-4">
        <PixelButton>Создать проект</PixelButton>
      </div>
    </div>
  )
}
