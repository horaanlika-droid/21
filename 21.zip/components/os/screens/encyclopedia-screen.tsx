"use client"

import { useState } from "react"
import { Search, ChevronRight } from "lucide-react"
import { ScreenHeader, TabBar, PixelIcon } from "@/components/os/primitives"
import { ENCYCLOPEDIA } from "@/lib/os-data"

type Group = "all" | "home" | "eco" | "law"

const TABS: { key: Group; label: string }[] = [
  { key: "all", label: "Все" },
  { key: "home", label: "Дом и двор" },
  { key: "eco", label: "Экология" },
  { key: "law", label: "Право" },
]

export function EncyclopediaScreen() {
  const [group, setGroup] = useState<Group>("all")
  const visible = ENCYCLOPEDIA.filter((c) => group === "all" || c.group === group)

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader
        title="Энциклопедия"
        right={
          <button aria-label="Поиск" className="flex h-8 w-8 items-center justify-center">
            <Search className="h-5 w-5" strokeWidth={2.25} />
          </button>
        }
      />

      <div className="px-4 py-3">
        <TabBar tabs={TABS} active={group} onChange={setGroup} />
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-4 pb-6 scrollbar-none">
        {visible.map((c) => (
          <button
            key={c.title}
            className="flex w-full items-center gap-3 border-2 border-border bg-card p-3 text-left pixel-shadow-sm transition-all active:translate-x-[2px] active:translate-y-[2px] active:shadow-none"
          >
            <PixelIcon icon={c.icon} />
            <div className="min-w-0 flex-1">
              <p className="font-display text-sm font-bold uppercase leading-tight">{c.title}</p>
              <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                {c.count} {plural(c.count)}
              </p>
            </div>
            <ChevronRight className="h-5 w-5 shrink-0" strokeWidth={2.5} />
          </button>
        ))}
      </div>
    </div>
  )
}

function plural(n: number) {
  const mod10 = n % 10
  const mod100 = n % 100
  if (mod10 === 1 && mod100 !== 11) return "статья"
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return "статьи"
  return "статей"
}
