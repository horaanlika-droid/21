"use client"

import { useState } from "react"
import Image from "next/image"
import { SlidersHorizontal, Plus, Minus, ChevronRight, TriangleAlert, Wrench, Vote } from "lucide-react"
import { ScreenHeader, Card } from "@/components/os/primitives"
import { MAP_POINTS, MAP_TYPES, type MapPoint } from "@/lib/os-data"
import { cn } from "@/lib/utils"

const PIN_GLYPH: Record<MapPoint["type"], React.ReactNode> = {
  problem: <TriangleAlert className="h-3.5 w-3.5" strokeWidth={2.5} />,
  task: <Wrench className="h-3.5 w-3.5" strokeWidth={2.5} />,
  project: <Plus className="h-4 w-4" strokeWidth={3} />,
  vote: <Vote className="h-3.5 w-3.5" strokeWidth={2.5} />,
}

export function MapScreen() {
  const [zoom, setZoom] = useState(1)
  const [selected, setSelected] = useState<MapPoint | null>(null)

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader
        title="Карта района"
        right={
          <button aria-label="Фильтр" className="flex h-8 w-8 items-center justify-center">
            <SlidersHorizontal className="h-5 w-5" strokeWidth={2.25} />
          </button>
        }
      />

      <div className="relative flex-1 overflow-hidden border-b-2 border-border bg-card">
        <div
          className="absolute inset-0 origin-center transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        >
          <Image
            src="/pixel/citymap.png"
            alt="Пиксельная изометрическая карта района"
            fill
            className="pixelated object-cover"
          />
          {MAP_POINTS.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelected(p)}
              aria-label={p.label}
              className="absolute -translate-x-1/2 -translate-y-full"
              style={{ left: `${p.x}%`, top: `${p.y}%` }}
            >
              <span className="flex flex-col items-center">
                <span
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-t-full rounded-bl-full border-2 border-border",
                    selected?.id === p.id ? "bg-background text-foreground" : "bg-foreground text-background",
                  )}
                >
                  {PIN_GLYPH[p.type]}
                </span>
                <span className="h-1.5 w-1.5 -translate-y-0.5 rotate-45 border-2 border-border bg-foreground" />
              </span>
            </button>
          ))}
        </div>

        {/* Zoom controls */}
        <div className="absolute bottom-3 right-3 flex flex-col border-2 border-border bg-card pixel-shadow-sm">
          <button
            aria-label="Приблизить"
            onClick={() => setZoom((z) => Math.min(1.8, +(z + 0.2).toFixed(1)))}
            className="flex h-9 w-9 items-center justify-center border-b-2 border-border"
          >
            <Plus className="h-4 w-4" strokeWidth={3} />
          </button>
          <button
            aria-label="Отдалить"
            onClick={() => setZoom((z) => Math.max(1, +(z - 0.2).toFixed(1)))}
            className="flex h-9 w-9 items-center justify-center"
          >
            <Minus className="h-4 w-4" strokeWidth={3} />
          </button>
        </div>

        {/* Selected label */}
        {selected && (
          <div className="absolute left-3 top-3 border-2 border-border bg-card px-3 py-2 pixel-shadow-sm">
            <div className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
              {MAP_TYPES.find((t) => t.key === selected.type)?.label}
            </div>
            <div className="font-display text-sm font-bold">{selected.label}</div>
          </div>
        )}
      </div>

      {/* Object types legend */}
      <Card className="m-3 mb-4 p-3">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Типы объектов</span>
          <ChevronRight className="h-4 w-4" strokeWidth={2.5} />
        </div>
        <div className="grid grid-cols-4 gap-2">
          {MAP_TYPES.map((t) => (
            <div key={t.key} className="flex flex-col items-center gap-1.5 text-center">
              <div className="flex h-10 w-10 items-center justify-center border-2 border-border bg-card">
                <t.icon className="h-5 w-5" strokeWidth={2.25} />
              </div>
              <span className="text-[9px] font-bold uppercase leading-tight">{t.label}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
