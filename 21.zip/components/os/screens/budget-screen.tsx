"use client"

import Image from "next/image"
import { ChevronLeft, Info } from "lucide-react"
import { ScreenHeader, PixelButton, Card } from "@/components/os/primitives"
import { BUDGET, BUDGET_TOTAL, formatMoney } from "@/lib/os-data"

export function BudgetScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <ScreenHeader
        title="Распределение бюджета"
        left={
          <button aria-label="Назад" onClick={onBack} className="flex h-8 w-8 items-center justify-center">
            <ChevronLeft className="h-6 w-6" strokeWidth={2.5} />
          </button>
        }
        right={
          <button aria-label="Справка" className="flex h-8 w-8 items-center justify-center">
            <Info className="h-5 w-5" strokeWidth={2.25} />
          </button>
        }
      />

      <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4 scrollbar-none">
        <Card className="flex items-center gap-3 p-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center border-2 border-border bg-card">
            <Image
              src="/pixel/robot.png"
              alt="Пиксельный робот AI-аналитик"
              width={48}
              height={48}
              className="pixelated h-10 w-10 object-contain"
            />
          </div>
          <div>
            <p className="font-display text-sm font-bold uppercase leading-tight">AI-анализ района</p>
            <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
              приоритеты на основе данных
            </p>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between border-b-2 border-border pb-3">
            <span className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Бюджет района</span>
            <span className="font-display text-lg font-bold tabular-nums">{formatMoney(BUDGET_TOTAL)} ₽</span>
          </div>

          <div className="mt-3 space-y-3">
            {BUDGET.map((b) => (
              <div key={b.label}>
                <div className="flex items-center justify-between text-[11px] font-bold uppercase">
                  <span>{b.label}</span>
                  <span className="tabular-nums text-muted-foreground">{formatMoney(b.amount)} ₽</span>
                </div>
                <div className="mt-1 flex items-center gap-2">
                  <div className="h-3 flex-1 border-2 border-border bg-card">
                    <div className="h-full dither" style={{ width: `${b.pct}%` }} />
                  </div>
                  <span className="w-9 text-right font-display text-xs font-bold tabular-nums">{b.pct}%</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="border-t-2 border-border p-4">
        <PixelButton variant="outline">Подробный отчёт</PixelButton>
      </div>
    </div>
  )
}
