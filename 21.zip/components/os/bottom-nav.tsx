"use client"

import { Map, BookOpen, MessageCircle, User } from "lucide-react"
import { cn } from "@/lib/utils"

export type NavKey = "map" | "encyclopedia" | "forum" | "profile"

const ITEMS: { key: NavKey; label: string; icon: typeof Map }[] = [
  { key: "map", label: "Карта", icon: Map },
  { key: "encyclopedia", label: "Энциклопедия", icon: BookOpen },
  { key: "forum", label: "Форум", icon: MessageCircle },
  { key: "profile", label: "Профиль", icon: User },
]

export function BottomNav({ active, onChange }: { active: NavKey; onChange: (k: NavKey) => void }) {
  return (
    <nav className="flex items-stretch border-t-2 border-border bg-card">
      {ITEMS.map((item) => {
        const isActive = active === item.key
        return (
          <button
            key={item.key}
            onClick={() => onChange(item.key)}
            aria-current={isActive ? "page" : undefined}
            className={cn(
              "flex flex-1 flex-col items-center gap-1 py-2.5 transition-colors",
              isActive ? "text-foreground" : "text-muted-foreground hover:text-foreground",
            )}
          >
            <item.icon className="h-5 w-5" strokeWidth={isActive ? 2.75 : 2} fill={isActive ? "currentColor" : "none"} />
            <span className="text-[9px] font-bold uppercase tracking-wide">{item.label}</span>
          </button>
        )
      })}
    </nav>
  )
}
